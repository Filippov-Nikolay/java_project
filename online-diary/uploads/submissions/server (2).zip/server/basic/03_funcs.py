x = 10

def get_x():
    return x

def set_x(new_value) :
    x = new_value
    print('x set to', x)

print( 'x =', get_x() )
set_x(20)
print( 'x =', get_x() )
