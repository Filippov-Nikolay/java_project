import json

j_str = '''{
    "x": 123,
    "y": 1.23,
    "b1": true,
    "b2": false,
    "n": null,
    "a": [1,2,3],
    "o": {
        "f1": "value",
        "f2": "значение"
    } 
}'''

def main():
    j = json.loads(j_str)
    print(type(j), j)

    for k in j:
        print(k, type(j[k]), j[k])

    j_str_2 = json.dumps(j)
    
    print(j_str_2)
    print(json.dumps(j, ensure_ascii=False, indent=4))

    json.dump(j, ensure_ascii=False, indent=4, fp=open("j.json", "w", encoding="utf-8"))

    try:
        j2 = json.load(fp=open("j.json", "r", encoding="utf-8"))
    except json.decoder.JSONDecodeError as err:
        print("Decode error: ", err)
    else: 
        print(j2)

if __name__ == '__main__':
    main()