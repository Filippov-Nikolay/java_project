def read_int(prompt: str) -> int:
    while True:
        try:
            return int(input(prompt))
        except ValueError:
            print("Ошибка: введите целое число.\n")

while True:
    start = read_int("От: ")
    end = read_int("До: ")

    if start == end:
        print("Ошибка: 'От' и 'До' не должны совпадать.\n")
        continue

    step = read_int("Шаг: ")

    if step == 0:
        print("Ошибка: шаг не может быть 0.")
        continue

    step_abs = abs(step)
    diff = abs(end - start)
    if diff % step_abs != 0:
        print(f"Ошибка: разность {diff} не кратна шагу {step_abs}. Измените шаг.\n")
        continue

    break

signed_step = step_abs if end > start else -step_abs

for x in range(start, end + (1 if signed_step > 0 else -1), signed_step):
    print(x, end=" ")
print()