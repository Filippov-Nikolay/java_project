def main() :
    lam1 = lambda x : print(x)
    lam1('Hello')
    lam2 = lambda x, y : print(x, y)
    lam2(10, 20)

if __name__ == '__main__':
    main()