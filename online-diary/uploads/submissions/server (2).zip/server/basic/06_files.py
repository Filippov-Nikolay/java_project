def create_file() -> None:
    filename = 'db.ini'
    file = None

    try:
        file = open(filename, mode='w', encoding='utf-8')
        file.write("# Данные для подключения к БД\n")
        file.write("host: localhost\rport: 3306\n")
        file.flush()

    except OSError as osError:
        print(f"OS error: {osError}")

    else :
        print(f"File '{filename}' created successfully.")

    finally:
        if file != None:
         file.close()   

def parse_ini(filename: str) -> dict | None:
    try:
        with open(filename, encoding='utf-8') as file:
            return {k.strip(): v.strip() for line in file if ':' in line for k, v in [line.split(':', 1)]}
    except OSError as osError:
        print(f"OS error: {osError}")
        return None

def readFile() -> None:
    filename = 'db.ini'
    file = None

    try:
        file = open(filename, mode='r', encoding='utf-8')
        print(file.read())     
    except OSError as osError:
        print(f"OS error: {osError}")
    else:
        print("File read successfully.")
    finally:
        if file != None:
         file.close()   

def read_as_string(filename: str) -> str | None:
        try:
          with open(filename, mode='r', encoding='utf-8') as file:   #with - автоматическое зщакрытие ресурсов
            return file.read()
        except OSError as osError:
            print(f"OS error: {osError}")
            return None
        # finally не нужен, т.к. with сам закроет файл
 
def main() -> None:
    create_file()
    print(parse_ini('db.ini'))

if __name__ == "__main__":
    main()