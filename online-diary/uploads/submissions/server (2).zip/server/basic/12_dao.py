import mysql.connector
import hashlib
import helper
import json
import sys

class DataAccessor:
    def __init__(self, ini_file="./db.json"):
        try:
            with open(ini_file, encoding="utf-8") as file:
                self.ini = json.load(file)
        except OSError as err:
            raise RuntimeError("Ini read error: " + str(err))

        try:
            self.db_connection = mysql.connector.connect( **self.ini )
        except mysql.connector.Error as err:
            raise RuntimeError("Connection error: " + str(err))
    

    def install(self):
        steps = [
            ("users", self._install_users),
            ("roles", self._install_roles),
            ("user_accesses", self._install_users_access),
            ("tokens", self._install_tokens),
            ("seed", self._seed_roles),
            ("seed_user", self._seed_users)
        ]

        row, done = self.make_status_printer([n for n, _ in steps], color=True)

        try:
            for name, fn in steps:
                try:
                    fn()
                    row(name, True)
                except Exception as e:
                    row(name, False, str(e))
                    raise RuntimeError(f"Step '{name}' failed") from e

            self.db_connection.commit()
            done(True)
        except Exception as err:
            self.db_connection.rollback()
            done(False, str(err))


    @staticmethod
    def make_status_printer(step_names, footer='all tables installed', color=True):
        names = list(step_names) + [footer]
        name_w   = max(len(n) for n in names)
        status_w = len("[ OK ]")
        rule = "─" * (name_w + 2 + status_w + 2 + len("MESSAGE"))

        def _c(ok, s):
            if not color:
                return s
            return f"\033[92m{s}\033[0m" if ok else f"\033[91m{s}\033[0m"

        def _print_header():
            print(rule)
            print(f"{'STEP'.ljust(name_w)}  {'STATUS'.ljust(status_w)}  MESSAGE")
            print(rule)

        def row(name, ok=True, msg=""):
            raw = "[ OK ]" if ok else "[FAIL]"
            print(f"{name.ljust(name_w)}  {_c(ok, raw)}  {msg}")

        def done(ok=True, msg=""):
            print(rule)
            row(footer, ok, msg)

        _print_header()
        return row, done


    def _install_users(self):
        sql = '''
            CREATE TABLE IF NOT EXISTS users (
                user_id             CHAR(36)      NOT NULL PRIMARY KEY DEFAULT(UUID()),
                user_name           VARCHAR(64)   NOT NULL,
                user_email          VARCHAR(128)  NOT NULL,
                user_birthdate      DATETIME          NULL,
                user_registered_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
                user_deleted_at     DATETIME          NULL
            ) ENGINE = InnoDb DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci
        '''

        if self.db_connection is None:
            raise RuntimeError("Connection empty in " + sys._getframe(0).f_code.co_name)
        with self.db_connection.cursor() as cursor:
            cursor.execute(sql)


    def _install_roles(self):
        sql = '''
            CREATE TABLE IF NOT EXISTS roles (
                role_id           VARCHAR(16)   NOT NULL PRIMARY KEY,
                role_description  VARCHAR(512)  NOT NULL,
                role_can_create   TINYINT       NOT NULL DEFAULT 0,
                role_can_read     TINYINT       NOT NULL DEFAULT 0,
                role_can_update   TINYINT       NOT NULL DEFAULT 0,
                role_can_delete   TINYINT       NOT NULL DEFAULT 0
            ) ENGINE = InnoDb DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci
        '''

        if self.db_connection is None:
            raise RuntimeError("Connection empty in " + sys._getframe(0).f_code.co_name)
        with self.db_connection.cursor() as cursor:
            cursor.execute(sql)


    def _install_users_access(self):
        sql = '''
            CREATE TABLE IF NOT EXISTS user_accesses (
                user_access_id     CHAR(36)     NOT NULL PRIMARY KEY DEFAULT (UUID()),
                user_id            CHAR(36)     NOT NULL,
                role_id            VARCHAR(16)  NOT NULL,
                user_access_login  VARCHAR(32)  NOT NULL,
                user_access_salt   CHAR(16)     NOT NULL,
                user_access_dk     CHAR(20)     NOT NULL COMMENT 'Derived Key by RFC 2898',
                UNIQUE (user_access_login)
            ) ENGINE = InnoDb DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;
        '''

        if self.db_connection is None:
            raise RuntimeError("Connection empty in " + sys._getframe(0).f_code.co_name)
        with self.db_connection.cursor() as cursor:
            cursor.execute(sql)


    def _install_tokens(self):
        sql = '''
            CREATE TABLE IF NOT EXISTS tokens (
                token_id         CHAR(36)    NOT NULL PRIMARY KEY DEFAULT (UUID()),
                user_access_id   CHAR(36)    NOT NULL,
                token_issued_at  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
                token_expired_at DATETIME    NOT NULL,
                token_type       VARCHAR(16) NULL
            ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;
        '''

        if self.db_connection is None:
            raise RuntimeError("Connection empty in " + sys._getframe(0).f_code.co_name)
        with self.db_connection.cursor() as cursor:
            cursor.execute(sql)


    def _hash(self, input: str) -> str:
        hash = hashlib.md5()
        hash.update(input.encode(encoding='utf-8'))

        return hash.hexdigest()


    def _kdf1(self, password: str, salt: str) -> str:
        iteration_count = 1000
        dk_len = 20

        t = self._hash(password + salt)

        for i in range(iteration_count):
            t = self._hash(t)
        return t[:dk_len]


    def kdf(self, password: str, salt: str) -> str:
        return self._kdf1(password, salt)


    def get_db_identity(self):
        ''' Generate ID by roles in DB '''
        
        sql = 'select uuid()'
        if self.db_connection is None:
            raise RuntimeError("Connection empty in " + sys._getframe(0).f_code.co_name)
        with self.db_connection.cursor() as cursor:
            cursor.execute(sql)
            return next(cursor)[0]


    def _seed_roles(self):
        sql = '''
            INSERT INTO roles(
                role_id, role_description, role_can_create, 
                role_can_read, role_can_update, role_can_delete
            )
            VALUES(%s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                role_description = VALUES(role_description),
                role_can_create = VALUES(role_can_create),
                role_can_read = VALUES(role_can_read),
                role_can_update = VALUES(role_can_update),
                role_can_delete = VALUES(role_can_delete)
        '''

        roles = [
            ('admin', 'Root administrator', 1, 1, 1, 1),
            ('user', 'Self registered user', 0, 0, 0, 0)
        ]

        if self.db_connection is None:
            raise RuntimeError("Connection empty in " + sys._getframe(0).f_code.co_name)
        with self.db_connection.cursor() as cursor:
            cursor.executemany(sql, roles)


    def _seed_users(self):
        id = 'd94d01e3-c2e2-11f0-bcb0-02502396f8b0'
        sql = '''
            INSERT INTO users(user_id, user_name, user_email)
            VALUES(%s, %s, %s)
            ON DUPLICATE KEY UPDATE
                user_name = VALUES(user_name),
                user_email = VALUES(user_email) 
        '''

        if self.db_connection is None:
            raise RuntimeError("Connection empty in " + sys._getframe(0).f_code.co_name)
        with self.db_connection.cursor() as cursor:
            cursor.execute(sql, (id, 'Default administrator', 'change.me@fake.net'))
            self.db_connection.commit()

        access_id = 'de1a3c57-c2e4-11f0-bcb0-02502396f8b'
        salt = helper.generate_salt()
        login = 'admin'
        password = 'admin'
        dk = self.kdf(password, salt)

        sql = '''
            INSERT INTO user_accesses(
                user_access_id,
                user_id,
                role_id,
                user_access_login,
                user_access_salt,
                user_access_dk
            )
            VALUES(%s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                user_id = VALUES(user_id),
                role_id = VALUES(role_id),
                user_access_login = VALUES(user_access_login),
                user_access_salt = VALUES(user_access_salt),
                user_access_dk = VALUES(user_access_dk)
        '''

        with self.db_connection.cursor() as cursor:
            cursor.execute(sql, (access_id, id, 'admin', login, salt, dk))


    def authentication(self, login: str, password: str) -> dict | None:
        sql = '''
            SELECT *
            FROM users u 
                JOIN user_accesses ua 
                ON u.user_id = ua.user_id 
            WHERE ua.user_access_login = %s
        '''

        if self.db_connection is None:
            raise RuntimeError("Connection empty in " + sys._getframe(0).f_code.co_name)
        with self.db_connection.cursor(dictionary=True) as cursor:
            cursor.execute(sql, (login,))
            row = next(cursor, None)
        
        if row is None:
            return None
        
        dk = self.kdf(password, row["user_access_salt"])
        return row if dk == row["user_access_dk"] else None


    def register_user(self, name: str, email: str, login: str, password: str, birthdate: str|None = None):
        sql = '''
            SELECT COUNT(*)
            FROM user_accesses
            WHERE user_access_login = %s
        '''

        if self.db_connection is None:
            raise RuntimeError("Connection empty in " + sys._getframe(0).f_code.co_name)
        with self.db_connection.cursor() as cursor:
            cursor.execute(sql, (login,))
            cnt = next(cursor)[0]
            self.db_connection.commit()

        if cnt > 0:
            raise ValueError("Login in use")
        
        user_id = self.get_db_identity()
        salt = helper.generate_salt()
        dk = self.kdf(password, salt)

        sql_user = '''
            INSERT INTO users(user_id, user_name, user_email)
            VALUES(%s, %s, %s)
        '''
        sql_user_accesses = '''
            INSERT INTO user_accesses(user_access_id, user_id, role_id, user_access_login, user_access_salt, user_access_dk)
            VALUES(UUID(), %s, 'user', %s, %s, %s)
        '''

        try:
            with self.db_connection.cursor() as cursor:
                cursor.execute(sql_user, (user_id, name, email))
                cursor.execute(sql_user_accesses, (user_id, login, salt, dk))
        except mysql.connector.Error as err:
            print(err)
            self.db_connection.rollback()
            raise RuntimeError(str(err))
        else:
            self.db_connection.commit()
            return user_id


def main():
    try:
        data_accessor = DataAccessor()
    except RuntimeError as err:
        print(err)
        return
    else:
        print("Connection:\t[ OK ]")

        data_accessor.install()
        
        ### methods
        print("\n=== PRINT ===")
        print(data_accessor.get_db_identity())
        print(data_accessor.kdf("123", "456"))
        print(data_accessor.helper())

    print("\n=== AUTHENTICATION ===")
    login = input("login: ")
    password = input("password: ")
    result = data_accessor.authentication(login, password)
    print("Access: ", "[successful]" if result else "[unsuccessful]")
    print(result)

    print("\n=== REGISTRATION ===")
    login = input("login: ")
    name = input("name: ")
    email = input("email: ")
    password = input("password: ")
    try:
        print(data_accessor.register_user(name, email, login, password))
    except Exception as err:
        print(err)


    # login: user
    # password: user123

if __name__ == '__main__':
    main()