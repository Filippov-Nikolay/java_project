import requests
import json

class RatesData:
    def __init__(self):
        self.exchange_date = None
        self.rates = []



class NbuRatesData(RatesData):
    url = 'https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?json'

    def __init__(self):
        req = requests.get(NbuRatesData.url)
        res = req.json()

        self.exchange_date = res[0]["exchangedate"]
        self.rates = [NbuRate(r) for r in res]

        self._by_abbr = {r.abbr.upper(): r for r in self.rates}

    def get(self, abbr: str):
        return self._by_abbr.get(abbr.upper())
        



class NbuRate:
    def __init__(self, j:dict):
        self.r030=j["r030"]
        self.name=j["txt"]
        self.rate=j["rate"]
        self.abbr=j["cc"]
        self.date=j["exchangedate"]

    def __str__(self):
        return "%s (%s) %f" % (self.abbr, self.name, self.rate)



def main():
    rates_data: RatesData = NbuRatesData()
    abbr = input("Enter currency: ").strip().upper()

    rate = rates_data.get(abbr)
    if rate:
        print("Курс для %s: %f (на %s)" % (rate.abbr, rate.rate, rate.date))
    else:
        print("Валюта '%s' не найдена." % abbr.upper())
    


if __name__ == '__main__':
    main()