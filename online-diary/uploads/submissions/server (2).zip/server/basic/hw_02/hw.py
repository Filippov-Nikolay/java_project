from math import prod

# 1. "Стратегии" как лямбды (кортеж пар: имя, функция)
methods = (
    ("среднее арифметическое", lambda xs: sum(xs) / len(xs)),
    ("среднее геометрическое", lambda xs: prod(xs) ** (1 / len(xs))),
    ("среднее гармоническое", lambda xs: len(xs) / sum(1 / x for x in xs)),
    ("среднее квадратическое", lambda xs: (sum(x*x for x in xs) / len(xs)) ** 0.5),
)

# 2. Данные: кортеж чисел
data = (6, 12, 4, 22, 17)

# 3. Функция сравнения: принимает кортеж данных и кортеж методов (лямбд)
def pick_max_mean(data_tuple: tuple, method_tuple: tuple):
    results = tuple((name, f(data_tuple)) for name, f in method_tuple)
    best_name, best_value = max(results, key=lambda item: item[1])

    return results, (best_name, best_value)

if __name__ == "__main__":
    results, best = pick_max_mean(data, methods)
    for name, value in results:
        print(f"{name}: {value:.6f}")
    print(f"\nМаксимум даёт: {best[0]} = {best[1]:.6f}")
