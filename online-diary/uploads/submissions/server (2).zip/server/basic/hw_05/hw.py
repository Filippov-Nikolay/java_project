import requests
from datetime import datetime, date

API_URL = 'https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?json'

class RatesData:
    def __init__(self, day: date):
        self.exchange_date: str | None = None
        self.rates: list[NbuRate] = []
        self._by_abbr: dict[str, NbuRate] = {}
        self._fetch(day)

    def _fetch(self, day: date) -> None:
        yyyymmdd = day.strftime("%Y%m%d")
        try:
            resp = requests.get(API_URL, params={"date": yyyymmdd}, timeout=10)
            resp.raise_for_status()
            data = resp.json()
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"Ошибка сети/HTTP: {e}")
        except ValueError as e:
            raise RuntimeError(f"Ошибка разбора JSON: {e}")

        # Пустой ответ (например, выходной/праздник)
        if not data:
            self.exchange_date = day.strftime("%d.%m.%Y")
            self.rates = []
            self._by_abbr = {}
            return

        self.exchange_date = data[0]["exchangedate"]
        self.rates = [NbuRate(item) for item in data]
        self._by_abbr = {r.abbr.upper(): r for r in self.rates}

    def get(self, abbr: str):
        return self._by_abbr.get(abbr.upper())


class NbuRate:
    def __init__(self, j: dict):
        self.r030 = j["r030"]
        self.name = j["txt"]
        self.rate = j["rate"]
        self.abbr = j["cc"]
        self.date = j["exchangedate"]

    def __str__(self):
        return f"{self.abbr} ({self.name}) {self.rate}"


def read_user_date() -> date:
    s = input("Введите дату (YYYY-MM-DD или DD.MM.YYYY): ").strip()
    dt = None
    for fmt in ("%Y-%m-%d", "%d.%m.%Y"):
        try:
            dt = datetime.strptime(s, fmt).date()
            break
        except ValueError:
            pass
    if dt is None:
        raise ValueError("Неверный формат даты. Используйте YYYY-MM-DD или DD.MM.YYYY.")

    today = date.today()
    if dt >= today:
        raise ValueError("Дата должна быть из прошлого (строго раньше сегодняшней).")
    return dt


def main():
    try:
        day = read_user_date()
        rates_data = RatesData(day)
    except ValueError as e:
        print(e)
        return
    except RuntimeError as e:
        print(e)
        return

    if not rates_data.rates:
        print(f"На {day.strftime('%d.%m.%Y')} данных нет (возможно, выходной/праздник).")
        return

    abbr = input("Введите код валюты (например, USD) или оставьте пустым для списка всех: ").strip().upper()
    if abbr:
        rate = rates_data.get(abbr)
        if rate:
            print(f"Курс для {rate.abbr}: {rate.rate:.4f} (на {rate.date})")
        else:
            print(f"Валюта '{abbr}' не найдена на {rates_data.exchange_date}.")
    else:
        for r in rates_data.rates:
            print(f"{r.abbr:>3}  {r.rate:>10.4f}  {r.name}")
        print(f"Всего валют: {len(rates_data.rates)} (на {rates_data.exchange_date})")


if __name__ == "__main__":
    main()
