w = int(input("Enter size: "))

for i in range(w):
    stars = 2 * i + 1
    spaces = w - i - 1

    print(' ' * spaces + '*' * stars)


number = range(1, 6)

even_mult = {
    n: [n * m for m in num if (n * m) % 2 == 0]
    for n in num
}

for n, evens in even_mult.items():
    print(f"{n} {evens} {sum(evens)}")

total_sum = sum(sum(evens) for evens in even_mult.values())
print(f"Sum: {total_sum}")