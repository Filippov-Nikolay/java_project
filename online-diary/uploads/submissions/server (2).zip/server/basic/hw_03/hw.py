def create_file() -> None:
    filename = 'db.ini'
    file = None

    try:
        file = open(filename, mode='w', encoding='utf-8')
        file.write("# Данные для подключения БД\n")
        file.write("host: localhost # размещение БД\n")
        file.write("port: 3306 # или port: 3308 для домашнего ПК\n")
        file.write("pass: 1:2 # : - часть пароля\n")
        file.write("; комментарий, начинающийся с точки с запятой\n")
        file.write("\n")  # пустая строка – как часть файла
        file.flush()

    except OSError as osError:
        print(f"OS error: {osError}")

    else:
        print(f"File '{filename}' created successfully.")

    finally:
        if file is not None:
            file.close()


def _strip_inline_comment(line: str) -> str:
    """
    Удаляем комментарий, начинающийся с '#' или ';'.
    Комментарий может быть в конце строки. Работает без кавычек/эскейпов.
    """
    if not line:
        return line

    hash_pos = line.find('#')
    semi_pos = line.find(';')

    cut_positions = [p for p in (hash_pos, semi_pos) if p != -1]
    if not cut_positions:
        return line.rstrip()

    cut_at = min(cut_positions)
    return line[:cut_at].rstrip()


def parse_ini(filename: str) -> dict | None:
    """
    Читаем ini-подобный файл формата 'key: value', игнорируя:
    - пустые строки;
    - полнострочные и частичные комментарии, начинающиеся с '#' или ';'.
    Разделение ключ/значение — по первому ':'; двоеточия в значении сохраняются.
    """
    try:
        with open(filename, encoding='utf-8') as file:
            result: dict[str, str] = {}

            for raw_line in file:
                # убираем перевод строки и хвостовой комментарий
                line = _strip_inline_comment(raw_line.rstrip('\r\n')).strip()

                # пропускаем пустые строки и строки без разделителя
                if not line or ':' not in line:
                    continue

                # только по ПЕРВОМУ ':'
                key, value = line.split(':', 1)
                key = key.strip()
                value = value.strip()

                if key:
                    result[key] = value

            return result

    except OSError as osError:
        print(f"OS error: {osError}")
        return None


def readFile() -> None:
    filename = 'db.ini'
    file = None

    try:
        file = open(filename, mode='r', encoding='utf-8')
        print(file.read())
    except OSError as osError:
        print(f"OS error: {osError}")
    else:
        print("File read successfully.")
    finally:
        if file is not None:
            file.close()


def read_as_string(filename: str) -> str | None:
    try:
        # with — автоматическое закрытие ресурса
        with open(filename, mode='r', encoding='utf-8') as file:
            return file.read()
    except OSError as osError:
        print(f"OS error: {osError}")
        return None
    # finally не нужен — with сам закроет файл


def main() -> None:
    create_file()
    readFile()
    parsed = parse_ini('db.ini')
    print(parsed)


if __name__ == "__main__":
    main()
