def throws() -> None:
    print("Throws error")
    raise TypeError

def main() -> None:
    try:
        throws ()
    except:
        print('error detected')

if __name__ == '__main__':
    main()