from math import gcd

class Fraction:
    def __init__(self, n: int, d: int = 1):
        if not isinstance(n, int) or not isinstance(d, int):
            raise TypeError("Числитель и знаменатель должны быть целыми")
        if d == 0:
            raise ZeroDivisionError("Знаменатель не может быть 0")

        # Нормализация знака и сокращение
        if d < 0:
            n, d = -n, -d
        g = gcd(abs(n), d)
        self.n = n // g
        self.d = d // g
        if self.n == 0:
            self.d = 1  # 0/x -> 0/1

    def __str__(self):
        return f"{self.n}/{self.d}"

    def __repr__(self):
        return f"Fraction({self.n}, {self.d})"

    # Явное сокращение (на случай, если нужно вызвать отдельно)
    def reduce(self):
        g = gcd(abs(self.n), self.d)
        self.n //= g
        self.d //= g
        if self.n == 0:
            self.d = 1
        return self

    # Вспомогательное приведение типов
    def _as_fraction(self, other):
        if isinstance(other, Fraction):
            return other
        if isinstance(other, int):
            return Fraction(other, 1)
        raise TypeError("Ожидается Fraction или int")

    # Арифметика (результат всегда сокращён)
    def __add__(self, other):
        o = self._as_fraction(other)
        return Fraction(self.n * o.d + o.n * self.d, self.d * o.d)
    __radd__ = __add__

    def __sub__(self, other):
        o = self._as_fraction(other)
        return Fraction(self.n * o.d - o.n * self.d, self.d * o.d)

    def __rsub__(self, other):
        o = self._as_fraction(other)
        return Fraction(o.n * self.d - self.n * o.d, o.d * self.d)

    def __mul__(self, other):
        o = self._as_fraction(other)
        return Fraction(self.n * o.n, self.d * o.d)
    __rmul__ = __mul__

    def __truediv__(self, other):
        o = self._as_fraction(other)
        if o.n == 0:
            raise ZeroDivisionError("Деление на ноль")
        return Fraction(self.n * o.d, self.d * o.n)

    def __rtruediv__(self, other):
        if self.n == 0:
            raise ZeroDivisionError("Деление на ноль")
        o = self._as_fraction(other)
        return Fraction(o.n * self.d, o.d * self.n)

    # Числовые представления
    def to_float(self) -> float:
        return self.n / self.d

    def to_int(self) -> int:
        # как int(): усечение к нулю
        return int(self.n / self.d)

    def __float__(self):
        return self.to_float()

    def __int__(self):
        return self.to_int()

    # Простое равенство
    def __eq__(self, other):
        try:
            o = self._as_fraction(other)
        except TypeError:
            return False
        return self.n == o.n and self.d == o.d



def main():
    a = Fraction(4, 6) # 2/3
    b = Fraction(3, 4)

    print(a, b) # 2/3 3/4
    print(a + b) # 17/12
    print(a - 1) # -1/3
    print(2 * b) # 3/2
    print(b / a) # 9/8
    print(float(Fraction(1, 2))) # 0.5
    print(int(Fraction(7, 3))) # 2
    print(Fraction(1, -2)) # -1/2



if __name__ == '__main__':
    main()