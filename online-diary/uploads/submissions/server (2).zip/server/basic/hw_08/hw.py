import mysql.connector
import hashlib
import hmac
import json
import sys
from math import ceil

class DataAccessor:
    def __init__(self, ini_file="./db.json"):
        try:
            with open(ini_file, encoding="utf-8") as file:
                self.ini = json.load(file)
        except OSError as err:
            raise RuntimeError("Ini read error: " + str(err))

        try:
            self.db_connection = mysql.connector.connect(**self.ini)
        except mysql.connector.Error as err:
            raise RuntimeError("Connection error: " + str(err))

    def install(self):
        steps = [
            ("users", self._install_users),
            ("roles", self._install_roles),
            ("user_accesses", self._install_users_access),
            ("tokens", self._install_tokens),
        ]

        row, done = self.make_status_printer([n for n, _ in steps], color=True)

        try:
            for name, fn in steps:
                try:
                    fn()
                    row(name, True)
                except Exception as e:
                    row(name, False, str(e))
                    raise RuntimeError(f"Step '{name}' failed") from e

            self.db_connection.commit()
            done(True)
        except Exception as err:
            self.db_connection.rollback()
            done(False, str(err))

    @staticmethod
    def make_status_printer(step_names, footer='all tables installed', color=True):
        names = list(step_names) + [footer]
        name_w   = max(len(n) for n in names)
        status_w = len("[ OK ]")
        rule = "─" * (name_w + 2 + status_w + 2 + len("MESSAGE"))

        def _c(ok, s):
            if not color:
                return s
            return f"\033[92m{s}\033[0m" if ok else f"\033[91m{s}\033[0m"

        def _print_header():
            print(rule)
            print(f"{'STEP'.ljust(name_w)}  {'STATUS'.ljust(status_w)}  MESSAGE")
            print(rule)

        def row(name, ok=True, msg=""):
            raw = "[ OK ]" if ok else "[FAIL]"
            print(f"{name.ljust(name_w)}  {_c(ok, raw)}  {msg}")

        def done(ok=True, msg=""):
            print(rule)
            row(footer, ok, msg)

        _print_header()
        return row, done

    def _install_users(self):
        sql = '''
            CREATE TABLE IF NOT EXISTS users (
                user_id             CHAR(36)      NOT NULL PRIMARY KEY DEFAULT(UUID()),
                user_name           VARCHAR(64)   NOT NULL,
                user_email          VARCHAR(128)  NOT NULL,
                user_birthdate      DATETIME          NULL,
                user_registered_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
                user_deleted_at     DATETIME          NULL
            ) ENGINE = InnoDb DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci
        '''

        if self.db_connection is None:
            raise RuntimeError("Connection empty in " + sys._getframe(0).f_code.co_name)
        with self.db_connection.cursor() as cursor:
            cursor.execute(sql)

    def _install_roles(self):
        sql = '''
            CREATE TABLE IF NOT EXISTS roles (
                role_id           VARCHAR(16)   NOT NULL PRIMARY KEY,
                role_description  VARCHAR(512)  NOT NULL,
                role_can_create   TINYINT       NOT NULL DEFAULT 0,
                role_can_read     TINYINT       NOT NULL DEFAULT 0,
                role_can_update   TINYINT       NOT NULL DEFAULT 0,
                role_can_delete   TINYINT       NOT NULL DEFAULT 0
            ) ENGINE = InnoDb DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci
        '''

        if self.db_connection is None:
            raise RuntimeError("Connection empty in " + sys._getframe(0).f_code.co_name)
        with self.db_connection.cursor() as cursor:
            cursor.execute(sql)

    def _install_users_access(self):
        sql = '''
            CREATE TABLE IF NOT EXISTS user_accesses (
                user_access_id     CHAR(36)     NOT NULL PRIMARY KEY DEFAULT (UUID()),
                user_id            CHAR(36)     NOT NULL,
                role_id            VARCHAR(16)  NOT NULL,
                user_access_login  VARCHAR(32)  NOT NULL,
                user_access_salt   CHAR(16)     NOT NULL,
                user_access_dk     CHAR(20)     NOT NULL COMMENT 'Derived Key by RFC 2898',
                UNIQUE (user_access_login)
            ) ENGINE = InnoDb DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;
        '''

        if self.db_connection is None:
            raise RuntimeError("Connection empty in " + sys._getframe(0).f_code.co_name)
        with self.db_connection.cursor() as cursor:
            cursor.execute(sql)

    def _install_tokens(self):
        sql = '''
            CREATE TABLE IF NOT EXISTS tokens (
                token_id         CHAR(36)    NOT NULL PRIMARY KEY DEFAULT (UUID()),
                user_access_id   CHAR(36)    NOT NULL,
                token_issued_at  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
                token_expired_at DATETIME    NOT NULL,
                token_type       VARCHAR(16) NULL
            ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;
        '''

        if self.db_connection is None:
            raise RuntimeError("Connection empty in " + sys._getframe(0).f_code.co_name)
        with self.db_connection.cursor() as cursor:
            cursor.execute(sql)

    def _hash(self, input: str) -> str:
        hash = hashlib.md5()
        hash.update(input.encode(encoding='utf-8'))
        return hash.hexdigest()
    
    def pbkdf2(self, password: str, salt: str, iterations: int, dk_len: int, h_name: str = 'sha1') -> bytes:
        p = password.encode('utf-8')
        s = salt.encode('utf-8')

        h = getattr(hashlib, h_name)
        hlen = h().digest_size
        blocks = (dk_len + hlen - 1) // hlen  # ceil

        dk = bytearray()
        for i in range(1, blocks + 1):
            # U1
            u = hmac.new(p, s + i.to_bytes(4, 'big'), h).digest()
            t = bytearray(u)
            # U2..Uc
            for _ in range(1, iterations):
                u = hmac.new(p, u, h).digest()
                for j in range(hlen):
                    t[j] ^= u[j]
            dk.extend(t)

        return bytes(dk[:dk_len])
    
    def _kdf1(self, password: str, salt: str) -> str:
        dk = self._pbkdf2(password, salt, iterations=1000, dk_len=10, h_name='sha1')
        return dk.hex() 

def main():
    try:
        data_accessor = DataAccessor()
    except RuntimeError as err:
        print(err)
        return
    else:
        dk_bytes = data_accessor.pbkdf2("password", "1234567890abcdef", iterations=1000, dk_len=10, h_name="sha1")
        print(dk_bytes)

        print("Connection:\t[ OK ]")
        data_accessor.install()

if __name__ == '__main__':
    main()
