import mysql.connector
from datetime import datetime

# CREATE DATABASE server_221;
# CREATE USER nf_221@localhost IDENTIFIED BY 'pass_221';
# GRANT ALL PRIVILEGES ON server_221.* TO nf_221@localhost;

db_ini = {
    'host': 'localhost',
    'port': 3306,
    'user': 'nf_221',
    'password': 'pass_221',
    'database': 'server_221',
    'charset': 'utf8mb4',
    'use_unicode': True,
    'collation': 'utf8mb4_unicode_ci'
}

db_connection = None

def connect_db():
    global db_connection

    try:
        db_connection = mysql.connector.connect( **db_ini )
    except mysql.connector.Error as err:
        print(err)
    else:
        print("Connection OK")


def show_database():
    global db_connection

    if db_connection is None : return

    try:
        cursor = db_connection.cursor()
        cursor.execute("SHOW DATABASES")
    except mysql.connector.Error as err:
        print(err)
    else:
        print(cursor.column_names)
        print('=============')
        for row in cursor:
            print(row)


def print_as_table(headers, rows):
    headers = [str(h) for h in headers]
    rows_s = [[ "" if v is None else str(v) for v in row ] for row in rows]
    widths = [max(len(headers[i]), max((len(r[i]) for r in rows_s), default=0))
              for i in range(len(headers))]

    def hline():
        print("+" + "+".join("-" * (w + 2) for w in widths) + "+")
    def rowline(cells):
        print("|" + "|".join(" " + cells[i].ljust(widths[i]) + " " for i in range(len(widths))) + "|")

    hline(); rowline(headers); hline()
    for r in rows_s: rowline(r)

    hline()


def run_uuid_query():
    global db_connection

    if db_connection is None:
        print("Нет соединения с БД. Сначала вызовите connect_db().")
        return
    
    try:
        cursor = db_connection.cursor()
        cursor.execute("SELECT UUID(), UUID()")

        rows = cursor.fetchall()
        headers = cursor.column_names
    except mysql.connector.Error as err:
        print(err)
    else:
        print_as_table(headers, rows)


def close_connection():
    db_connection.close()


def plural_days_ru(n: int) -> str:
    n = abs(int(n))

    if 11 <= (n % 100) <= 14:
        return "дней"
    last = n % 10
    
    if last == 1:
        return "день"
    
    if 2 <= last <= 4:
        return "дня"
    
    return "дней"


def run_date_diff_console():
    global db_connection

    if db_connection is None:
        print("Нет соединения с БД. Сначала вызовите connect_db().")
        return

    user_input = input("Введите дату (ГГГГ-ММ-ДД): ").strip()

    # Предварительная Питон-валидация формата и корректности календарной даты
    try:
        datetime.strptime(user_input, "%Y-%m-%d")
    except ValueError:
        print("Ошибка: некорректная дата. Ожидается формат ГГГГ-ММ-ДД.")
        return

    # Доп. валидация на стороне СУБД (CAST к DATE внутри запроса)
    sql = "SELECT DATEDIFF(CURRENT_DATE(), CAST(%s AS DATE)) AS diff_days"

    try:
        cursor = db_connection.cursor(prepared=True)
        cursor.execute(sql, (user_input,))
        row = cursor.fetchone()

        if row is None:
            print("Пустой результат.")
            return
    except mysql.connector.Error as err:
        print("Ошибка СУБД:", err)
        print("Запрос:", sql)
        return
    else:
        diff = int(row[0])  # > 0 — в прошлом, < 0 — в будущем, 0 — сегодня

    if diff == 0: print("Дата является текущей")
    elif diff > 0: print(f"дата в прошлом за {diff} {plural_days_ru(diff)} от текущей даты")
    else:
        days = abs(diff)
        print(f"Дата в будущем через {days} {plural_days_ru(days)} от текущей даты")


def main():
    connect_db()
    # show_database()
    # run_uuid_query()
    run_date_diff_console()
    close_connection()


if __name__ == '__main__':
    main()