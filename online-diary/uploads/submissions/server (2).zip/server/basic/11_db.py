import mysql.connector

# CREATE DATABASE server_221;
# CREATE USER nf_221@localhost IDENTIFIED BY 'pass_221';
# GRANT ALL PRIVILEGES ON server_221.* TO nf_221@localhost;

db_ini = {
    'host': 'localhost',
    'port': 3306,
    'user': 'nf_221',
    'password': 'pass_221',
    'database': 'server_221',
    'charset': 'utf8mb4',
    'use_unicode': True,
    'collation': 'utf8mb4_unicode_ci'
}

db_connection = None

def connect_db():
    global db_connection

    try:
        db_connection = mysql.connector.connect( **db_ini )
    except mysql.connector.Error as err:
        print(err)
    else:
        print("Connection OK")


def show_database():
    global db_connection

    if db_connection is None : return

    try:
        cursor = db_connection.cursor()
        cursor.execute("SHOW DATABASES")
    except mysql.connector.Error as err:
        print(err)
    else:
        print(cursor.column_names)
        print('=============')
        for row in cursor:
            print(row)


def close_connection():
    db_connection.close()


def main():
    connect_db()
    show_database()
    close_connection()


if __name__ == '__main__':
    main()