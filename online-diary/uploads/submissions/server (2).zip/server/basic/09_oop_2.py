class Point:
    def __init__(
            self,
            x=0.0,
            y=0.0
        ):
        self.x = x
        self.y = y

    def __str__(self):
        return "Point(%f, %f)" % (self.x, self.y)
    
    def __repr__(self):
        return "(%f, %f)" % (self.x, self.y)
    
    def __add__(self, other):
        if isinstance(other, Point):
            return Point(other.x + self.x, other.y + self.y)
        else:
            raise TypeError("Point additional requires other Point")
        
    def __mul__(self, other):
        '''Multiplication by a number - gives a new point.
        Multiplication by a point is treated as scalar multiplication and
        gives a number'''
        if isinstance(other, (int, float)):
            return Point(self.x * other, self.y * other)
        elif isinstance(other, Point):
            return self.x * other.x + self.y * other.y
        else:
            raise TypeError("Point multiplication requires other Point or number")
    
    def magnitude(self):
        return (self.x ** 2 + self.y ** 2) ** (0.5)


def main():
    p1 = Point(1, 2)
    p2 = Point(3, 4)

    Point.x = 10

    print(str(p1))
    print(p2.magnitude())
    print(p1 + p2)
    print(p1 * p2)
    # print(p1 + 2)
    # print(p1 + 2j) 

if __name__ == '__main__':
    main()