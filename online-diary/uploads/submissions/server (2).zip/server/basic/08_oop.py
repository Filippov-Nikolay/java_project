class Point:
    x = 0
    y = 0

def main():
    p1 = Point()
    p2 = Point()
    print(p1.x, p1.y)
    print(p2.x, p2.y)

    Point.x = 10
    print(p1.x, p1.y)
    print(p2.x, p2.y)

    p1.x = 20
    print(p1.x, p1.y)
    print(p2.x, p2.y)

    del p1.x
    print(p1.x, p1.y)
    print(p2.x, p2.y)

if __name__ == '__main__':
    main()