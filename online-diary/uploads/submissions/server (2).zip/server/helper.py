import string
import random

def generate_salt(len: int = 16) -> str:
    symbols = string.ascii_letters + string.digits
    return ''.join(random.choice(symbols) for _ in range(len))