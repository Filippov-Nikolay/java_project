#!C:/Users/nf/AppData/Local/Python/pythoncore-3.14-64/python.exe

print("Content-Type: text/html")
print()
print("<h1>Hello, world!</h1>")

'''  '''