class HomeController:
    def do_get(self):
        print("HomeController::do_get")