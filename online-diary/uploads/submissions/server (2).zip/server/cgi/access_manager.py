#!C:/Users/nf/AppData/Local/Python/pythoncore-3.14-64/python.exe

import os
import sys, io
import importlib

def header_name(hdr: str) -> str:
    return "-".join(
        s[0].upper() + s[1:].lower()
        for s in hdr.split('_')
    )

# Настраиваем вывод в UTF-8
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

request = { 
    k:v for k, v in os.environ.items() if k in (
        "REQUEST_URI", 
        "QUERY_STRING", 
        "REQUEST_METHOD"
    ) 
}
qr_params = { k: v 
    for k, v in (item.split('=', 1) if '=' in item else (item, None)
            for item in request['QUERY_STRING'].split('&')) }

headers = { header_name(k[5:]):v for k, v in os.environ.items() if k.startswith('HTTP_') }


if not 'htctrl' in qr_params:
    print('Status: 403 Forbidden')
    print()
    exit()


#
# path = request['REQUEST_URI'].split('?', 1)[0]
# static_dir = "."
# if not path.endswith('/'):
#     try:
#         with open(static_dir + path) as file:
#             print()
#             print(file.read())
#         exit()
#     except: pass


#
path = request['REQUEST_URI'].split('?', 1)[0]

parts = path.split('/', 4)

lang = parts[1] if len(parts) > 1 and parts[1].strip() else 'uk-UA'
controller = parts[2] if len(parts) > 2 and parts[2].strip() else 'Home'
action = parts[3] if len(parts) > 3 and parts[3].strip() else 'Index'
id = parts[4] if len(parts) > 4 and parts[4].strip() else None

module_name = controller.lower() + '_controller'
class_name = controller.capitalize() + 'Controller'
action_name = 'do_' + request['REQUEST_METHOD'].lower()


# Сортируем параметры окружения по алфавиту по имени переменной (ключу)
envs = ""
for key, value in sorted(request.items(), key=lambda item: item[0].lower()):
    envs += f"<tr><td>{key}</td><td>{value}</td></tr>\n"

hdrs = ""
for key, value in sorted(headers.items(), key=lambda item: item[0].lower()):
    hdrs += f"<tr><td>{key}</td><td>{value}</td></tr>\n"

qp = ""
for key, value in sorted(qr_params.items(), key=lambda item: item[0].lower()):
    qp += f"<tr><td>{key}</td><td>{value}</td></tr>\n"

html = f'''
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>CGI Py</title>
    <link rel="icon" href="/icon.png" />
    <style>
        table {{
            border-collapse: collapse;
            width: 100%;
        }}
        th, td {{
            border: 1px solid #555;
            padding: 4px 8px;
            text-align: left;
        }}
        th {{
            background-color: #eee;
        }}
    </style>
</head>
<body>
    <h1>Параметры окружения</h1>
    <p>CGI Apache (Python)</p>

    <h2>lang: {lang}</h2>
    <h2>controller: {controller}</h2>
    <h2>action: {action}</h2>
    <h2>id: {id}</h2>
    <h2>module_name: {module_name}</h2>
    <h2>action_name: {action_name}</h2>

    <table>
        <thead>
            <tr>
                <th>Переменная</th>
                <th>Значение</th>
            </tr>
        </thead>
        <tbody>
            {envs}
            <tr><td></td><td></td></tr>
            {hdrs}
            <tr><td></td><td></td></tr>
            {qp}
        </tbody>
    </table>

    <img src="/icon.png" width="100">
</body>
</html>
'''

print("Content-Type: text/html; charset=utf-8")
print()
print(html)
