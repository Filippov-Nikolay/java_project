"""
JWT validation helpers with nested JWT handling (JOSE cty == "JWT").

Implements step 8 of the validation standard:
If the JOSE Header contains a "cty" (content type) value of "JWT",
the message is itself a JWT that must be re-validated from step 1.
"""

import base64
import hashlib
import hmac
import json
import re
import uuid
from typing import Any, Dict, Optional


class JwtValidationError(Exception):
    """Raised for unrecoverable JWT validation problems."""


def _b64url_decode(data: str, label: str) -> bytes:
    """Decode Base64URL without padding."""
    try:
        padded = data + "=" * (-len(data) % 4)
        return base64.urlsafe_b64decode(padded.encode("ascii"))
    except Exception as exc:
        raise JwtValidationError(f"Invalid base64 in {label}") from exc


def _b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _compute_hs256_signature(header_b64: str, payload_b64: str, secret: str) -> str:
    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    mac = hmac.new(secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
    return _b64url_encode(mac)


def _is_uuid(value: str) -> bool:
    try:
        uuid.UUID(value)
        return True
    except Exception:
        return False


def _is_email(value: str) -> bool:
    # Простая проверка формата email
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", value))


def _validate_claims(payload: Dict[str, Any]) -> tuple[bool, Optional[str], Optional[str]]:
    sub = payload.get("sub")
    if not sub:
        return False, "missing_sub", "'sub' claim is required."
    if not isinstance(sub, str) or not _is_uuid(sub):
        return False, "invalid_sub", "'sub' must be a UUID."

    iss = payload.get("iss")
    if iss is None:
        return False, "missing_iss", "'iss' claim is required."
    if iss != "Server-KN-P-221":
        return False, "invalid_iss", "'iss' must equal 'Server-KN-P-221'."

    name = payload.get("name")
    email = payload.get("email")
    if not name and not email:
        return False, "missing_identity", "At least one of 'name' or 'email' is required."

    if email:
        if not isinstance(email, str) or not _is_email(email):
            return False, "invalid_email", "'email' is not valid."

    return True, None, None


def validate_jwt(
    token: str,
    secret: str,
    *,
    max_depth: int = 3,
    depth: int = 0,
) -> Dict[str, Any]:
    """
    Validate a JWT with HS256 and handle nested JWT when JOSE cty == "JWT".

    Returns a dict containing header, payload, signature validity,
    optional nested validation result, and error/message fields.
    """
    result: Dict[str, Any] = {
        "depth": depth,
        "token": token,
        "header": None,
        "payload": None,
        "signature_valid": False,
        "nested": None,
        "error": None,
        "message": None,
    }

    if depth > max_depth:
        result["error"] = "max_depth_exceeded"
        result["message"] = "Nested JWT depth limit exceeded."
        return result

    parts = token.split(".")
    if len(parts) != 3:
        result["error"] = "format_error"
        result["message"] = "JWT must have 3 parts (header.payload.signature)."
        return result

    header_b64, payload_b64, signature_b64 = parts

    try:
        header_raw = _b64url_decode(header_b64, "header")
        header = json.loads(header_raw.decode("utf-8"))
        result["header"] = header
    except Exception as exc:
        result["error"] = "header_error"
        result["message"] = str(exc)
        return result

    alg = header.get("alg")
    if alg != "HS256":
        result["error"] = "unsupported_alg"
        result["message"] = f"Unsupported alg: {alg}. Only HS256 is accepted."
        return result

    try:
        payload_raw = _b64url_decode(payload_b64, "payload")
        payload_text = payload_raw.decode("utf-8")
    except Exception as exc:
        result["error"] = "payload_error"
        result["message"] = str(exc)
        return result

    # Attempt to parse payload as JSON unless we have to treat it as nested JWT later.
    try:
        payload_obj = json.loads(payload_text)
        result["payload"] = payload_obj
    except json.JSONDecodeError:
        payload_obj = None
        result["payload"] = payload_text

    expected_sig = _compute_hs256_signature(header_b64, payload_b64, secret)
    result["signature_valid"] = hmac.compare_digest(signature_b64, expected_sig)
    if not result["signature_valid"]:
        result["error"] = "invalid_signature"
        result["message"] = "Signature verification failed."
        return result

    # Claims validation (only when payload is JSON object and not a nested JWT container)
    if header.get("cty") != "JWT":
        if payload_obj is None or not isinstance(payload_obj, dict):
            result["error"] = "payload_not_json"
            result["message"] = "Payload must be a JSON object."
            return result
        ok_claims, claim_err, claim_msg = _validate_claims(payload_obj)
        if not ok_claims:
            result["error"] = claim_err
            result["message"] = claim_msg
            return result

    # Step 8: If cty == "JWT", validate nested JWT recursively.
    if header.get("cty") == "JWT":
        try:
            nested_token = payload_text.strip()
            nested_result = validate_jwt(
                nested_token,
                secret,
                max_depth=max_depth,
                depth=depth + 1,
            )
            result["nested"] = nested_result
        except Exception as exc:
            result["error"] = "nested_error"
            result["message"] = f"Failed to validate nested JWT: {exc}"
            return result

    return result
