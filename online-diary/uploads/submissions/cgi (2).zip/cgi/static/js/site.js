document.addEventListener("DOMContentLoaded", () => {
    initUserAuthTests();
});

function initUserAuthTests() {
    const container = document.getElementById("api-auth-tests");
    if (!container) {
        return;
    }

    const methodSelect = document.getElementById("http-method-select");
    const customInput = document.getElementById("custom-authorization");
    const customBtn = document.getElementById("custom-send-btn");
    const responseOutput = document.getElementById("response-output");
    const authHeaderBadge = document.getElementById("auth-header-pill");

    const scenarios = {
        "no-header": {
            label: "No Authorization header",
            header: null,
            expectStatus: 401,
            expectMessage: "Missing Authorization header."
        },
        "wrong-scheme": {
            label: "Wrong scheme: Bearer ...",
            header: "Bearer abc.def.ghi",
            expectStatus: 401,
            expectMessage: "Unsupported auth scheme. Use Basic."
        },
        "short-token": {
            label: "Basic token too short",
            header: "Basic eA==",
            expectStatus: 400,
            expectMessage: "Basic credentials string too short."
        },
        "invalid-base64": {
            label: "Basic with invalid base64 chars",
            header: "Basic !!!",
            expectStatus: 400,
            expectMessage: "Invalid base64 credentials."
        },
        "missing-colon": {
            label: "Basic decoded without colon",
            header: "Basic dXNlcg==",
            expectStatus: 400,
            expectMessage: "Credentials must contain ':' separator."
        },
        "wrong-credentials": {
            label: "Basic wrong login/password",
            header: "Basic d3Jvbmc6cGFzcw==",
            expectStatus: 401,
            expectMessage: "Invalid username or password."
        }
    };

    const scenarioResults = {};
    const scenarioOrder = Object.keys(scenarios);
    scenarioOrder.forEach((key) => {
        scenarioResults[key] = { status: "pending" };
    });

    const summaryList = document.getElementById("summary-list");
    const summaryOverall = document.getElementById("summary-overall");
    const updateSummary = () => renderSummary(scenarioOrder, scenarioResults, summaryList, summaryOverall);

    document.querySelectorAll("[data-scenario]").forEach((btn) => {
        btn.addEventListener("click", () => {
            const id = btn.dataset.scenario;
            runScenario(id, scenarios[id], methodSelect.value, responseOutput, authHeaderBadge, scenarioResults, updateSummary);
        });
    });

    customBtn.addEventListener("click", () => {
        const header = customInput.value.trim();
        runScenario(
            null,
            {
                label: "Custom Authorization header",
                header: header || null
            },
            methodSelect.value,
            responseOutput,
            authHeaderBadge,
            scenarioResults,
            updateSummary
        );
    });

    renderPlaceholder(responseOutput);
    updateAuthBadge(authHeaderBadge, null);
    updateSummary();
}

async function runScenario(scenarioId, scenario, method, responseOutput, authHeaderBadge, scenarioResults, updateSummary) {
    const targetUrl = "/uk-UA/user?htctrl=1";
    const headers = {};
    if (scenario.header) {
        headers["Authorization"] = scenario.header;
    }
    if (method === "POST") {
        headers["Content-Type"] = "application/json";
    }

    let body = null;
    if (method === "POST") {
        body = JSON.stringify({ sample: true });
    }

    let status = 0;
    let statusText = "";
    let payload = {};

    try {
        const res = await fetch(targetUrl, {
            method,
            headers,
            body
        });
        status = res.status;
        statusText = res.statusText || "";
        const text = await res.text();
        try {
            payload = JSON.parse(text);
        } catch {
            payload = { raw: text };
        }
    } catch (err) {
        status = 0;
        statusText = err.message;
        payload = { error: "client_error", message: err.message };
    }

    updateAuthBadge(authHeaderBadge, payload.auth_header ?? scenario.header ?? null);
    const evaluation = evaluateScenario(scenario, status, payload);
    if (scenarioId) {
        scenarioResults[scenarioId] = evaluation.pass === true
            ? { status: "pass" }
            : evaluation.pass === false
                ? { status: "fail" }
                : { status: "pending" };
    }
    renderResponse({
        scenario,
        method,
        status,
        statusText,
        payload,
        responseOutput,
        passText: evaluation.passText
    });
    updateSummary();
}

function renderPlaceholder(responseOutput) {
    responseOutput.textContent = "Choose a scenario to run a request against /uk-UA/user.";
}

function renderResponse({ scenario, method, status, statusText, payload, responseOutput, passText }) {
    const authLine = scenario.header ? scenario.header : "<missing>";
    const expectedStatus = scenario.expectStatus ?? "-";
    const expectedMessage = scenario.expectMessage ?? "-";

    const messageFromBody = payload?.message ?? "";
    const statusLine = statusText ? `${status} ${statusText}` : (status || "n/a");

    const pass = passText;

    const lines = [
        `Scenario: ${scenario.label}`,
        `Method: ${method}`,
        `Authorization: ${authLine}`,
        `Status: ${statusLine}`,
        `Expected status: ${expectedStatus}`,
        `Expected message: ${expectedMessage}`,
        `Check: ${pass}`,
        "",
        JSON.stringify(payload, null, 2)
    ];

    responseOutput.textContent = lines.join("\n");
}

function evaluateScenario(scenario, status, payload) {
    const expectedStatus = scenario.expectStatus ?? "-";
    const expectedMessage = scenario.expectMessage ?? "-";
    const messageFromBody = payload?.message ?? "";

    if (scenario.expectStatus === undefined && scenario.expectMessage === undefined) {
        return { pass: null, passText: "No expectation (custom)" };
    }

    const statusOk = typeof expectedStatus === "number" ? status === expectedStatus : true;
    const messageOk = expectedMessage === "-" ? true : messageFromBody === expectedMessage;
    const pass = statusOk && messageOk;
    return { pass, passText: pass ? "PASS" : "FAIL" };
}

function renderSummary(order, results, listEl, overallEl) {
    if (!listEl || !overallEl) return;
    const total = order.length;
    let completed = 0;
    let passed = 0;
    let failed = 0;

    listEl.innerHTML = "";
    order.forEach((key) => {
        const res = results[key] || { status: "pending" };
        const li = document.createElement("li");
        li.textContent = `${key}: ${res.status}`;
        if (res.status === "pass") {
            completed += 1;
            passed += 1;
            li.classList.add("summary-pass");
        } else if (res.status === "fail") {
            completed += 1;
            failed += 1;
            li.classList.add("summary-fail");
        } else {
            li.classList.add("summary-pending");
        }
        listEl.appendChild(li);
    });

    if (completed === total) {
        overallEl.textContent = `All ${total} scenarios finished: ${passed} PASS, ${failed} FAIL.`;
    } else {
        overallEl.textContent = `Completed ${completed}/${total} scenarios. Remaining: ${total - completed}.`;
    }
}

function updateAuthBadge(el, value) {
    if (!el) return;
    const displayValue = value ? value : "<missing>";
    el.textContent = displayValue;
    el.title = `Last Authorization header seen: ${displayValue}`;
}
