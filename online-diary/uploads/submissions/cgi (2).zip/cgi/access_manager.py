#!C:/Users/nf/AppData/Local/Programs/Python/Python313/python.exe

DEV_MODE = True

import os
import sys
import io
import importlib

from models.request import CgiRequest

# Сырой бинарный вывод (на него будем писать статику)
raw_out = sys.stdout.buffer


def header_name(hdr: str) -> str:
    return "-".join(
        s[0].upper() + s[1:].lower()
        for s in hdr.split('_')
    )


# -----------------------------
# 0. Базовые данные запроса
# -----------------------------
server = {
    k: v for k, v in os.environ.items() if k in (
        "REQUEST_URI",
        "QUERY_STRING",
        "REQUEST_METHOD"
    )
}

query_string = server.get("QUERY_STRING", "") or ""

qr_params = {
    k: v
    for k, v in (
        item.split('=', 1) if '=' in item else (item, None)
        for item in query_string.split('&')
        if item
    )
}

headers = {
    header_name(k[5:]): v
    for k, v in os.environ.items()
    if k.startswith('HTTP_')
}

path = server.get('REQUEST_URI', '/').split('?', 1)[0]

# -----------------------------
# 1. Пытаемся отдать статику
# -----------------------------
if not path.endswith('/') and '.' in path.split('/')[-1]:
    ext = path.split('.')[-1].lower()
    allowed_types = {
        'png': 'image/png',
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'css': 'text/css',
        'js': 'text/javascript',
        'ico': 'image/x-icon',
        'gif': 'image/gif',
        'webp': 'image/webp',
        'svg': 'image/svg+xml'
    }

    if ext in allowed_types:
        try:
            # файл ищем в каталоге static относительно CGI-скрипта
            filepath = os.path.normpath(
                os.path.join(os.getcwd(), 'static', path.lstrip('/'))
            )

            static_root = os.path.abspath('static')
            if not filepath.startswith(static_root):
                raise ValueError("Path traversal")

            with open(filepath, 'rb') as f:
                # ВАЖНО: пишем сразу в raw_out байтами
                raw_out.write(
                    f"Content-Type: {allowed_types[ext]}\r\n\r\n".encode('ascii')
                )
                raw_out.write(f.read())
            raw_out.flush()
            sys.exit(0)
        except Exception:
            # Если файла нет — вернём 404 для статики и завершимся
            raw_out.write(b"Status: 404 Not Found\r\n")
            raw_out.write(b"Content-Type: text/plain; charset=utf-8\r\n\r\n")
            raw_out.write(f"Static file not found: {path}".encode('utf-8'))
            raw_out.flush()
            sys.exit(0)

sys.stdout = io.TextIOWrapper(raw_out, encoding='utf-8')

if 'htctrl' not in qr_params:
    print('Status: 403 Forbidden')
    print()
    sys.exit(0)

parts = path.split('/', 4)

lang = parts[1] if len(parts) > 1 and parts[1].strip() else 'uk-UA'
controller = parts[2] if len(parts) > 2 and parts[2].strip() else 'Home'
module_name = controller.lower() + '_controller'
class_name = controller.capitalize() + 'Controller'

sys.path.append("./")

try:
    controller_module = importlib.import_module(f"controllers.{module_name}")

    controller_class = getattr(controller_module, class_name)
    controller_object = controller_class(
        CgiRequest(
            server=server,
            query_params=qr_params,
            headers=headers,
            path=path,
            controller=controller,
            path_parts=parts[1:]
        )
    )

    controller_action = getattr(controller_object, "serve")
    controller_action()
except Exception as e:
    print("Content-Type: text/html; charset=utf-8")
    print()
    print(f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Ошибка</title>
    </head>
    <body>
        <h1>Ошибка выполнения</h1>
        <p>Произошла ошибка при выполнении запроса:</p>
        <p><strong>Ошибка:</strong> {str(e)}</p>
        <p><strong>Детали:</strong></p>
        <ul>
            <li>Путь: {path}</li>
            <li>Модуль: controllers.{module_name}</li>
            <li>Класс: {class_name}</li>
        </ul>
    </body>
    </html>
    """)
finally:
    sys.stdout.flush()
