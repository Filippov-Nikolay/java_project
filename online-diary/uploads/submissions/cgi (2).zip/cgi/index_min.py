#!C:/Users/nf/AppData/Local/Programs/Python/Python313/python.exe

print("Content-Type: text/html")
print()
print("<h1>Hello, world!</h1>")

'''  '''
