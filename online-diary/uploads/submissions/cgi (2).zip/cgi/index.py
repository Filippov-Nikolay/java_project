#!C:/Users/nf/AppData/Local/Programs/Python/Python313/python.exe

import os
import sys, io

# Настраиваем вывод в UTF-8
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# Сортируем параметры окружения по алфавиту по имени переменной (ключу)
rows = ""
for key, value in sorted(os.environ.items(), key=lambda item: item[0].lower()):
    rows += f"<tr><td>{key}</td><td>{value}</td></tr>\n"

html = f'''
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>CGI Py</title>
    <link rel="icon" href="/icon.png" />
    <style>
        table {{
            border-collapse: collapse;
            width: 100%;
        }}
        th, td {{
            border: 1px solid #555;
            padding: 4px 8px;
            text-align: left;
        }}
        th {{
            background-color: #eee;
        }}
    </style>
</head>
<body>
    <h1>Параметры окружения</h1>
    <p>CGI Apache (Python)</p>

    <table>
        <thead>
            <tr>
                <th>Переменная</th>
                <th>Значение</th>
            </tr>
        </thead>
        <tbody>
            {rows}
        </tbody>
    </table>
</body>
</html>
'''

print("Content-Type: text/html; charset=utf-8")
print()
print(html)
