import base64
import json

from models.request import CgiRequest


class UserController:
    VALID_USER = "demo"
    VALID_PASSWORD = "secret"

    def __init__(self, request: CgiRequest):
        self.request = request

    def serve(self):
        action = "do_" + self.request.request_method.lower()
        controller_action = getattr(self, action, None)

        if controller_action:
            controller_action()
        else:
            self._json_response(
                405,
                {"error": "method_not_allowed", "message": "Method not allowed."}
            )

    def _status_line(self, code: int) -> str:
        mapping = {
            200: "200 OK",
            400: "400 Bad Request",
            401: "401 Unauthorized",
            405: "405 Method Not Allowed",
        }
        return mapping.get(code, f"{code} Unknown")

    def _json_response(self, status_code: int, payload: dict):
        print(f"Status: {self._status_line(status_code)}")
        print("Content-Type: application/json; charset=utf-8")
        print()
        print(json.dumps(payload, ensure_ascii=False))

    def _get_test_data(self):
        return {
            "int": 10,
            "float": 1e-3,
            "str": "Hello",
            "cyr": "Privet",
        }

    def _auth_result(self):
        auth_header = self.request.headers.get("Authorization")
        if not auth_header:
            return False, 401, {
                "error": "missing_header",
                "message": "Missing Authorization header."
            }

        header_value = auth_header.strip()
        lowered = header_value.lower()

        if lowered.startswith("basic "):
            token = header_value[6:].strip()

            if token and not all(c.isalnum() or c in "+/=" for c in token):
                return False, 400, {
                    "error": "invalid_base64",
                    "message": "Invalid base64 credentials."
                }

            if len(token) < 8:
                return False, 400, {
                    "error": "short_token",
                    "message": "Basic credentials string too short."
                }

            try:
                decoded_bytes = base64.b64decode(token, validate=True)
                decoded_str = decoded_bytes.decode("utf-8")
            except Exception:
                return False, 400, {
                    "error": "invalid_base64",
                    "message": "Invalid base64 credentials."
                }

            if ":" not in decoded_str:
                return False, 400, {
                    "error": "missing_colon",
                    "message": "Credentials must contain ':' separator."
                }

            username, password = decoded_str.split(":", 1)
            if username != self.VALID_USER or password != self.VALID_PASSWORD:
                return False, 401, {
                    "error": "invalid_credentials",
                    "message": "Invalid username or password."
                }

            return True, 200, {
                "auth_user": username,
                "auth_header": auth_header
            }

        if lowered.startswith("bearer"):
            return False, 401, {
                "error": "unsupported_scheme",
                "message": "Unsupported auth scheme. Use Basic."
            }

        return False, 400, {
            "error": "bad_format",
            "message": "Bad Authorization header format. Expected: Basic <credentials>."
        }

    def _respond(self):
        ok, status_code, details = self._auth_result()
        details["auth_header"] = details.get("auth_header") or self.request.headers.get("Authorization")

        if not ok:
            self._json_response(status_code, details)
            return

        data = self._get_test_data()
        data["auth_header"] = details["auth_header"]
        data["auth_user"] = details["auth_user"]
        self._json_response(200, data)

    def do_get(self):
        self._respond()

    def do_post(self):
        self._respond()
