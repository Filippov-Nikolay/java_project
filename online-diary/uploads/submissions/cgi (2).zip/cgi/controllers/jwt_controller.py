import json
from typing import Optional

from models.request import CgiRequest
from models.jwt_validator import validate_jwt, JwtValidationError


class JwtController:
    def __init__(self, request: CgiRequest):
        self.request = request

    def serve(self):
        action = "do_" + self.request.request_method.lower()
        controller_action = getattr(self, action, None)
        if controller_action:
            controller_action()
        else:
            self._respond_text(405, "Method Not Allowed")

    def do_get(self):
        qp = self.request.query_params
        token = qp.get("token")
        secret = qp.get("secret")
        fmt = (qp.get("format") or "").lower()
        wants_json = fmt == "json"

        result = None
        if token and secret:
            try:
                result = validate_jwt(token, secret)
            except Exception as exc:
                result = {
                    "error": "exception",
                    "message": str(exc),
                }

            if wants_json:
                self._respond_json(200, result)
                return

        self._render_html(token or "", secret or "", result)

    # ---------------- helpers ----------------
    def _respond_text(self, code: int, message: str):
        print(f"Status: {code} {message}")
        print("Content-Type: text/plain; charset=utf-8")
        print()
        print(message)

    def _respond_json(self, code: int, payload: dict):
        status_line = f"{code} OK" if code == 200 else f"{code}"
        print(f"Status: {status_line}")
        print("Content-Type: application/json; charset=utf-8")
        print()
        print(json.dumps(payload, ensure_ascii=False, indent=2))

    def _render_html(self, token: str, secret: str, result: Optional[dict]):
        try:
            with open("./views/_layout.html", "r", encoding="utf-8") as f:
                layout = f.read()
            with open("./views/jwt_index.html", "r", encoding="utf-8") as f:
                body = f.read()
        except FileNotFoundError as e:
            self._respond_text(500, f"Template not found: {e}")
            return

        result_block = (
            json.dumps(result, ensure_ascii=False, indent=2) if result else "Вставьте JWT и секрет, затем нажмите Validate."
        )

        replacements = {
            "%%TOKEN%%": token,
            "%%SECRET%%": secret,
            "%%RESULT%%": result_block,
        }
        for key, value in replacements.items():
            body = body.replace(key, value)

        print("Content-Type: text/html; charset=utf-8")
        print()
        print(layout.replace("<!-- RenderBody -->", body))
