# controllers/order_controller.py
from models.request import CgiRequest
import json


class OrderController:
    def __init__(self, request: CgiRequest):
        self.request = request

    def serve(self):
        method = self.request.request_method.upper()

        handlers = {
            "GET": self.do_get,
            "POST": self.do_post,
            "PUT": self.do_put,
            "PATCH": self.do_patch,
            "DELETE": self.do_delete,
        }

        handler = handlers.get(method)
        if handler is None:
            self._method_not_allowed()
            return

        if not self._has_custom_header():
            return

        handler()

    def do_get(self):
        data = {
            "data": [
                {"id": 1, "status": "new", "total": 1500, "currency": "UAH"},
                {"id": 2, "status": "processing", "total": 3200, "currency": "UAH"},
            ],
            "meta": {"count": 2},
        }
        self._json_response(data)

    def do_post(self):
        order_id = 1001
        data = {
            "data": {
                "id": order_id,
                "status": "created",
                "total": 1500,
                "currency": "UAH",
                "received": self.request.query_params,
            }
        }
        location = f"/uk-UA/order/{order_id}"
        self._json_response(data, status="201 Created", extra_headers={"Location": location})

    def do_put(self):
        order_id = 1001
        data = {
            "data": {
                "id": order_id,
                "status": "updated",
                "total": 1800,
                "currency": "UAH",
                "received": self.request.query_params,
            }
        }
        self._json_response(data)

    def do_patch(self):
        order_id = 1001
        data = {
            "data": {
                "id": order_id,
                "status": "partially-updated",
                "total": 1800,
                "currency": "UAH",
                "updated_fields": ["status"],
                "received": self.request.query_params,
            }
        }
        self._json_response(data)

    def do_delete(self):
        self._json_response(data=None, status="204 No Content")

    def _has_custom_header(self) -> bool:
        header_value = self.request.headers.get("Custom-Header")
        if header_value:
            self.custom_header_value = header_value
            return True

        self._forbidden_missing_header()
        return False

    def _forbidden_missing_header(self):
        print("Status: 403 Forbidden")
        print("Content-Type: application/json; charset=utf-8")
        print()
        print(
            json.dumps(
                {
                    "error": "Missing required header",
                    "message": "Requests to /order must include Custom-Header.",
                    "required_header": "Custom-Header",
                },
                ensure_ascii=False,
                indent=2,
            )
        )

    def _json_response(self, data, status="200 OK", extra_headers=None):
        print(f"Status: {status}")

        if extra_headers:
            for key, value in extra_headers.items():
                print(f"{key}: {value}")

        if data is None:
            print()
            return

        header_value = getattr(self, "custom_header_value", None)
        if header_value and isinstance(data, dict) and "custom_header" not in data:
            data["custom_header"] = header_value

        print("Content-Type: application/json; charset=utf-8")
        print()
        print(json.dumps(data, ensure_ascii=False, indent=2))

    def _method_not_allowed(self):
        print("Status: 405 Method Not Allowed")
        print("Content-Type: application/json; charset=utf-8")
        print()
        print(
            json.dumps(
                {
                    "error": "Method Not Allowed",
                    "api": "order",
                    "allowed": ["GET", "POST", "PUT", "PATCH", "DELETE"],
                },
                ensure_ascii=False,
                indent=2,
            )
        )
